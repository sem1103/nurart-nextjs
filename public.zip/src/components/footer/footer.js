export default function Footer(){
    return(
        <>
            <h4>I Footer</h4>
        </>
    )
}