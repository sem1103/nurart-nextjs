
import Polygraphy from './Poligrafy';

export const metadata = {
    title: "NurArt - Poliqrafiyalar: vizit kartları, broşuralar, bukletlər ",
    description: "İşiniz üçün yüksək keyfiyyətli çap məhsulları: vizit kartları, bukletlər, broşuralar, afişalar və kataloqlar. Professional dizayn və çap. İndi sifariş edin!"
  };



export default function Page() {
    return <Polygraphy />
}